# Ultiwrite Forensics SDK — prepared local package

This typed dependency-free client is restricted to `https://ultiwrite.co/api/v1`. It contains no analyzer logic and does not share credentials or entitlements with the main Ultiwrite platform. Registry ownership is unverified, so install the local wheel named `ultiwrite-forensics-sdk-local` only after review.

```bash
python -m build
python -m pip install dist/ultiwrite_forensics_sdk_local-0.1.0-py3-none-any.whl
```

Create a product-scoped key at `https://ultiwrite.co/developers`. The API does not expose account email; verify the selected key’s product profile, scopes, allowance, and key budget with `client.usage()`.

```python
import os
from pathlib import Path
from ultiwrite_forensics_sdk import Client, UploadFile, create_request_key

client = Client(os.environ["ULTIWRITE_FORENSICS_API_KEY"])
created = client.create_analysis(
    UploadFile("synthetic.pdf", Path("synthetic.pdf").read_bytes(), "application/pdf"),
    request_key=create_request_key(),
)
completed = client.wait_for_analysis(created.data["id"])
print(completed.data["status"])
print(client.findings(created.data["id"]).data)
```

Reads use bounded retries. Analysis creation is retried only with the same UUID request key and exact body. An accepted delete is not represented as completed cleanup; poll/read according to the API lifecycle. Original and report expiry remain governed by the live standalone policy.
