import hashlib, json, threading, unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from ultiwrite_forensics_sdk import ApiError, Client, UploadFile

ANALYSIS_ID="11111111-1111-4111-8111-111111111111"
class Handler(BaseHTTPRequestHandler):
    calls=[]
    def log_message(self,*_args): pass
    def send_json(self,status,value): self.send_response(status);self.send_header("Content-Type","application/json");self.send_header("X-Request-Id",f"req_{len(self.calls)}");self.end_headers();self.wfile.write(json.dumps(value).encode())
    def do_GET(self):
        self.calls.append((self.command,self.path,dict(self.headers)))
        if self.path=="/api/v1/usage": self.send_json(200,{"available":1,"reserved":0,"api_execution":True,"profile":"ultiwrite-forensics@1","limits":{}})
        elif self.path==f"/api/v1/analyses/{ANALYSIS_ID}/result.json":
            body=json.dumps({"findings":[{"id":"fixture"}]}).encode();self.send_response(200);self.send_header("Content-Type","application/json");self.send_header("X-Content-Sha256",hashlib.sha256(body).hexdigest());self.end_headers();self.wfile.write(body)
        else:self.send_json(404,{"error":"not_found","detail":"private fixture prose"})
    def do_POST(self):
        size=int(self.headers.get("Content-Length","0"));body=self.rfile.read(size);self.calls.append((self.command,self.path,dict(self.headers),body));self.send_json(202,{"id":ANALYSIS_ID,"status":"queued"})

class Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server=ThreadingHTTPServer(("127.0.0.1",0),Handler);cls.thread=threading.Thread(target=cls.server.serve_forever,daemon=True);cls.thread.start();cls.client=Client("fixture-key",base_url=f"http://127.0.0.1:{cls.server.server_port}/api/v1",allow_insecure_loopback=True)
    @classmethod
    def tearDownClass(cls):cls.server.shutdown();cls.thread.join()
    def setUp(self):Handler.calls.clear()
    def test_usage_profile(self):self.assertEqual(self.client.usage().data["profile"],"ultiwrite-forensics@1");self.assertEqual(Handler.calls[0][2]["Authorization"],"Bearer fixture-key")
    def test_idempotent_analysis(self):
        value=self.client.create_analysis(UploadFile("fixture.pdf",b"%PDF-fixture","application/pdf"),request_key=ANALYSIS_ID);self.assertEqual(value.data["status"],"queued");self.assertEqual(Handler.calls[0][2]["Idempotency-Key"],ANALYSIS_ID)
    def test_findings_artifact(self):self.assertEqual(self.client.findings(ANALYSIS_ID).data["findings"][0]["id"],"fixture");self.assertEqual(Handler.calls[0][0],"GET")
    def test_safe_error(self):
        with self.assertRaises(ApiError) as caught:self.client.status(ANALYSIS_ID)
        self.assertEqual(caught.exception.code,"not_found");self.assertNotIn("private fixture prose",str(caught.exception))
if __name__=="__main__":unittest.main()
