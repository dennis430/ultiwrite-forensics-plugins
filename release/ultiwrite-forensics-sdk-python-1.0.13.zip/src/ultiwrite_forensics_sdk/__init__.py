"""Typed thin client for the standalone Ultiwrite Forensics API."""
from __future__ import annotations

import hashlib
import json
import re
import secrets
import time
import uuid
from dataclasses import dataclass
from email.utils import parsedate_to_datetime
from typing import Any, Callable, Generic, Mapping, TypeVar
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit
from urllib.request import HTTPRedirectHandler, Request, build_opener

CANONICAL_BASE_URL = "https://ultiwrite.co/api/v1"
ARTIFACTS = ("report.pdf", "metadata-analytics.pdf", "result.json", "manifest.json", "deliverables.zip")
_UUID = re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$", re.I)
_CODE = re.compile(r"^[a-z0-9_-]{1,100}$", re.I)
_TRANSIENT = {429, 503, 504}
T = TypeVar("T")


class _NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, *_args: Any, **_kwargs: Any) -> None: return None


@dataclass(frozen=True)
class ResponseMeta:
    request_id: str | None
    retry_after_seconds: float = 0


@dataclass(frozen=True)
class ApiResult(Generic[T]):
    data: T
    meta: ResponseMeta


@dataclass(frozen=True)
class UploadFile:
    name: str
    data: bytes
    content_type: str = "application/octet-stream"


class ApiError(RuntimeError):
    def __init__(self, code: str, *, status: int | None = None, request_id: str | None = None,
                 retry_after_seconds: float = 0, analysis_id: str | None = None) -> None:
        super().__init__(f"Ultiwrite Forensics request stopped: {code}")
        self.code, self.status, self.request_id = code, status, request_id
        self.retry_after_seconds, self.analysis_id = retry_after_seconds, analysis_id
        self.retryable = status in _TRANSIENT or code in {"transport_error", "deadline"}


def create_request_key() -> str: return str(uuid.uuid4())


def _retry_after(value: str | None) -> float:
    if not value: return 0
    if value.isdigit(): return float(value)
    try: return max(0, parsedate_to_datetime(value).timestamp() - time.time())
    except (TypeError, ValueError, OverflowError): return 0


def _identifier(value: str) -> str:
    if not isinstance(value, str) or not _UUID.fullmatch(value): raise TypeError("A UUID analysis id is required")
    return value


class Client:
    def __init__(self, api_key: str, *, base_url: str = CANONICAL_BASE_URL, max_retries: int = 2,
                 timeout_seconds: int = 60, allow_insecure_loopback: bool = False,
                 sleep: Callable[[float], None] = time.sleep, opener: Any = None) -> None:
        if not isinstance(api_key, str) or not api_key or any(c.isspace() for c in api_key): raise TypeError("A product-scoped Ultiwrite Forensics API key is required")
        parsed = urlsplit(base_url); loopback = parsed.scheme == "http" and parsed.hostname in {"127.0.0.1", "::1", "localhost"}
        if parsed.username or parsed.password or parsed.query or parsed.fragment or not parsed.path.endswith("/api/v1") or (parsed.scheme != "https" and not (allow_insecure_loopback and loopback)): raise TypeError("base_url must be an HTTPS /api/v1 URL; HTTP is restricted to explicit loopback tests")
        if not 0 <= max_retries <= 5: raise TypeError("max_retries must be 0 through 5")
        self.__api_key = api_key; self.base_url = base_url.rstrip("/"); self.max_retries = max_retries
        self.timeout_seconds, self.sleep, self.opener = timeout_seconds, sleep, opener or build_opener(_NoRedirect())

    def _url(self, path: str) -> str:
        if not isinstance(path, str) or not path.startswith("/"): raise TypeError("API path must begin with /")
        relative = re.sub(r"^/api/v1/?", "", path).lstrip("/"); url = f"{self.base_url}/{relative}"
        base, selected = urlsplit(self.base_url), urlsplit(url)
        if selected.scheme != base.scheme or selected.netloc != base.netloc or not selected.path.startswith(base.path + "/") or selected.username or selected.password or selected.fragment: raise TypeError("Refused off-origin or non-API URL")
        return url

    @staticmethod
    def _read(response: Any, limit: int) -> bytes:
        chunks: list[bytes] = []; size = 0
        while True:
            chunk = response.read(65536)
            if not chunk: return b"".join(chunks)
            size += len(chunk)
            if size > limit: raise ApiError("response_too_large")
            chunks.append(chunk)

    def _request(self, method: str, path: str, *, body: bytes | None = None,
                 headers: Mapping[str, str] | None = None, request_key: str | None = None,
                 retryable_write: bool = False) -> ApiResult[dict[str, Any]]:
        method = method.upper()
        if method not in {"GET", "POST", "DELETE"}: raise TypeError("Unsupported method")
        if request_key and not _UUID.fullmatch(request_key): raise TypeError("request_key must be a UUID")
        attempts = self.max_retries + 1 if method == "GET" or (method == "POST" and request_key and retryable_write) else 1
        request_headers = {"Authorization": f"Bearer {self.__api_key}", "Accept": "application/json", "Accept-Encoding": "identity", **(headers or {})}
        if request_key: request_headers["Idempotency-Key"] = request_key
        for attempt in range(attempts):
            try: response = self.opener.open(Request(self._url(path), data=body, headers=request_headers, method=method), timeout=self.timeout_seconds)
            except HTTPError as error: response = error
            except (URLError, OSError, TimeoutError): raise ApiError("transport_error") from None
            with response:
                response_meta = ResponseMeta(response.headers.get("X-Request-Id"), _retry_after(response.headers.get("Retry-After")))
                if response.status in _TRANSIENT and attempt + 1 < attempts:
                    self.sleep(max(0.5 * 2 ** attempt, response_meta.retry_after_seconds)); continue
                raw = self._read(response, 65536 if response.status >= 400 else 8 * 1024 * 1024)
                try: value = json.loads(raw)
                except (ValueError, UnicodeDecodeError): value = None
                if not 200 <= response.status < 300:
                    candidate = value.get("error") if isinstance(value, dict) else None
                    if isinstance(candidate, dict): candidate = candidate.get("code")
                    code = candidate if isinstance(candidate, str) and _CODE.fullmatch(candidate) else f"http_{response.status}"
                    raise ApiError(code, status=response.status, request_id=response_meta.request_id, retry_after_seconds=response_meta.retry_after_seconds)
                if not isinstance(value, dict): raise ApiError("invalid_json_response", status=response.status, request_id=response_meta.request_id)
                return ApiResult(value, response_meta)
        raise ApiError("retry_budget_exhausted")

    def capabilities(self) -> ApiResult[dict[str, Any]]: return self._request("GET", "/capabilities")
    def usage(self) -> ApiResult[dict[str, Any]]: return self._request("GET", "/usage")

    def analyses(self, limit: int = 50) -> ApiResult[dict[str, Any]]:
        if not isinstance(limit, int) or not 1 <= limit <= 100: raise TypeError("limit must be 1 through 100")
        return self._request("GET", f"/analyses?limit={limit}")

    @staticmethod
    def _multipart(file: UploadFile, external_checks: bool) -> tuple[bytes, str]:
        if not isinstance(file, UploadFile) or not file.data or re.search(r"[\\/\r\n\0]", file.name): raise TypeError("file needs a plain name and nonempty bytes")
        boundary = f"uf-{secrets.token_hex(18)}"
        prefix = (f"--{boundary}\r\nContent-Disposition: form-data; name=\"externalChecks\"\r\n\r\n{str(bool(external_checks)).lower()}\r\n"
                  f"--{boundary}\r\nContent-Disposition: form-data; name=\"file\"; filename=\"{file.name}\"\r\nContent-Type: {file.content_type}\r\n\r\n").encode()
        return prefix + file.data + f"\r\n--{boundary}--\r\n".encode(), boundary

    def create_analysis(self, file: UploadFile, *, request_key: str, external_checks: bool = False) -> ApiResult[dict[str, Any]]:
        body, boundary = self._multipart(file, external_checks)
        return self._request("POST", "/analyses", body=body, headers={"Content-Type": f"multipart/form-data; boundary={boundary}"}, request_key=request_key, retryable_write=True)

    def authorize_direct_upload(self, declaration: Mapping[str, Any]) -> ApiResult[dict[str, Any]]:
        key = declaration.get("requestKey")
        if not isinstance(key, str) or not _UUID.fullmatch(key): raise TypeError("declaration.requestKey must be a UUID")
        return self._request("POST", "/uploads", body=json.dumps(declaration).encode(), headers={"Content-Type": "application/json"}, request_key=key, retryable_write=True)

    def transfer_delegated(self, permission: Mapping[str, Any], data: bytes) -> None:
        try: parsed = urlsplit(str(permission["url"])); headers = permission["headers"]; method = permission["method"]
        except (KeyError, TypeError): raise TypeError("Invalid delegated upload permission") from None
        loopback = parsed.scheme == "http" and parsed.hostname in {"127.0.0.1", "::1", "localhost"} and self.base_url.startswith("http://")
        if (parsed.scheme != "https" and not loopback) or parsed.username or parsed.password or parsed.fragment or method not in {"POST", "PUT"} or not isinstance(headers, dict): raise TypeError("Invalid delegated upload permission")
        for name, value in headers.items():
            if not isinstance(value, str) or "\r" in name + value or "\n" in name + value or self.__api_key in value: raise TypeError("Invalid delegated upload permission")
        try: response = self.opener.open(Request(str(permission["url"]), data=data, headers=headers, method=method), timeout=self.timeout_seconds)
        except HTTPError as error: response = error
        except (URLError, OSError, TimeoutError): raise ApiError("upload_transport_error") from None
        with response:
            if not 200 <= response.status < 300: raise ApiError("upload_failed", status=response.status)

    def status(self, analysis_id: str) -> ApiResult[dict[str, Any]]: return self._request("GET", f"/analyses/{_identifier(analysis_id)}")

    def wait_for_analysis(self, analysis_id: str, *, interval_seconds: float = 5, timeout_seconds: float = 900) -> ApiResult[dict[str, Any]]:
        deadline = time.monotonic() + timeout_seconds
        while True:
            current = self.status(analysis_id); state = current.data.get("status")
            if state == "completed" and not current.data.get("evidence", {}).get("locked"): return current
            if state in {"failed", "cancelled", "deleting", "deleted"}: return current
            if time.monotonic() + interval_seconds > deadline: raise ApiError("processing_timeout", analysis_id=analysis_id)
            self.sleep(interval_seconds)

    def delete_analysis(self, analysis_id: str) -> ApiResult[dict[str, Any]]: return self._request("DELETE", f"/analyses/{_identifier(analysis_id)}")
    def unlock(self, analysis_id: str, request_key: str) -> ApiResult[dict[str, Any]]: return self._request("POST", f"/analyses/{_identifier(analysis_id)}/unlock", request_key=request_key, retryable_write=True)

    def artifact(self, analysis_id: str, artifact: str, *, max_bytes: int = 128 * 1024 * 1024) -> ApiResult[bytes]:
        if artifact not in ARTIFACTS and artifact != "metadata.json": raise TypeError("Unsupported artifact")
        request = Request(self._url(f"/analyses/{_identifier(analysis_id)}/{artifact}"), headers={"Authorization": f"Bearer {self.__api_key}", "Accept": "*/*", "Accept-Encoding": "identity"}, method="GET")
        try: response = self.opener.open(request, timeout=self.timeout_seconds)
        except HTTPError as error: response = error
        except (URLError, OSError, TimeoutError): raise ApiError("transport_error", analysis_id=analysis_id) from None
        with response:
            response_meta = ResponseMeta(response.headers.get("X-Request-Id"), _retry_after(response.headers.get("Retry-After")))
            if not 200 <= response.status < 300:
                raw = self._read(response, 65536)
                try: value = json.loads(raw)
                except (ValueError, UnicodeDecodeError): value = None
                candidate = value.get("error") if isinstance(value, dict) else None
                if isinstance(candidate, dict): candidate = candidate.get("code")
                raise ApiError(candidate if isinstance(candidate, str) and _CODE.fullmatch(candidate) else f"http_{response.status}", status=response.status, request_id=response_meta.request_id, analysis_id=analysis_id)
            if response.headers.get("Content-Encoding", "identity").lower() != "identity": raise ApiError("invalid_artifact_encoding", analysis_id=analysis_id)
            data = self._read(response, max_bytes)
            if not data: raise ApiError("empty_artifact", analysis_id=analysis_id)
            expected = response.headers.get("X-Content-Sha256")
            if expected and (not re.fullmatch(r"[a-f0-9]{64}", expected, re.I) or hashlib.sha256(data).hexdigest() != expected.lower()): raise ApiError("artifact_hash_mismatch", analysis_id=analysis_id)
            return ApiResult(data, response_meta)

    def findings(self, analysis_id: str) -> ApiResult[dict[str, Any]]:
        result = self.artifact(analysis_id, "result.json")
        try: value = json.loads(result.data)
        except (ValueError, UnicodeDecodeError): raise ApiError("invalid_result_json", analysis_id=analysis_id) from None
        if not isinstance(value, dict): raise ApiError("invalid_result_json", analysis_id=analysis_id)
        return ApiResult(value, result.meta)


__all__ = ["ARTIFACTS", "ApiError", "ApiResult", "CANONICAL_BASE_URL", "Client", "ResponseMeta", "UploadFile", "create_request_key"]
