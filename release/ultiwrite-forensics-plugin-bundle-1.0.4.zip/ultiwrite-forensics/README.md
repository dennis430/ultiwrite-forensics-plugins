# Ultiwrite Forensics release handoff

Offline collection of prepared host artifacts. This bundle is not a host-specific submission format and is not evidence of publication. Microsoft still requires its portal-issued DCR reference. See SUBMISSIONS.md.
