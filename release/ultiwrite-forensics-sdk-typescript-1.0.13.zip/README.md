# Ultiwrite Forensics SDK — prepared local package

This thin typed client is restricted to the standalone document-forensics API at `https://ultiwrite.co/api/v1`. It contains no analyzer logic and does not share main-platform credentials, accounts, grants, histories, or hosts. Registry ownership is unverified, so `ultiwrite-forensics-sdk-local` is private and installed from a reviewed local tarball.

```bash
npm pack --ignore-scripts
npm install ./ultiwrite-forensics-sdk-local-0.1.0.tgz
```

Create and rotate a product-scoped API key at `https://ultiwrite.co/developers`. The API has no email-identity endpoint: use `usage()` to verify that the selected key is active and review its scopes/budget.

```js
import { readFile } from 'node:fs/promises'
import { ForensicsClient, createRequestKey } from 'ultiwrite-forensics-sdk-local'

const client = new ForensicsClient({ apiKey: process.env.ULTIWRITE_FORENSICS_API_KEY })
const created = await client.createAnalysis(
  { name: 'synthetic.pdf', type: 'application/pdf', bytes: await readFile('synthetic.pdf') },
  { requestKey: createRequestKey() },
)
const completed = await client.waitForAnalysis(created.data.id)
console.log(completed.data.status)
console.log((await client.findings(created.data.id)).data)
```

Reads use bounded retries. An analysis POST is retried only with the same server-enforced UUID request key and exact payload. Deletion returns the server’s accepted lifecycle state; it is not relabeled as verified deletion. Original and report expiry remain governed by the live standalone retention policy.
