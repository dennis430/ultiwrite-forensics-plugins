import { createHash, randomUUID } from 'node:crypto'

export const CANONICAL_BASE_URL = 'https://ultiwrite.co/api/v1'
export const ARTIFACTS = ['report.pdf', 'metadata-analytics.pdf', 'result.json', 'manifest.json', 'deliverables.zip']
const TRANSIENT = new Set([429, 503, 504])
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i
const SAFE_CODE = /^[a-z0-9_-]{1,100}$/i
const delay = milliseconds => new Promise(resolve => setTimeout(resolve, milliseconds))

export class ForensicsApiError extends Error {
  constructor(code, { status, requestId, retryAfterMs = 0, analysisId } = {}) {
    super(`Ultiwrite Forensics request stopped: ${code}`)
    this.name = 'ForensicsApiError'; this.code = code; this.status = status; this.requestId = requestId
    this.retryAfterMs = retryAfterMs; this.analysisId = analysisId
    this.retryable = TRANSIENT.has(status) || ['transport_error', 'deadline'].includes(code)
  }
}

export function createRequestKey() { return randomUUID() }

function retryAfter(value) {
  if (!value) return 0
  if (/^\d+$/.test(value.trim())) return Number(value) * 1000
  const date = Date.parse(value); return Number.isFinite(date) ? Math.max(0, date - Date.now()) : 0
}

function validateBase(value, allowInsecureLoopback) {
  const url = new URL(value)
  const loopback = url.protocol === 'http:' && ['127.0.0.1', '[::1]', 'localhost'].includes(url.hostname)
  if (url.username || url.password || url.search || url.hash || !url.pathname.endsWith('/api/v1') || (url.protocol !== 'https:' && !(allowInsecureLoopback && loopback))) throw new TypeError('baseUrl must be an HTTPS /api/v1 URL; HTTP is restricted to explicit loopback tests')
  return url.href.replace(/\/$/, '')
}

function identifier(value) {
  if (typeof value !== 'string' || !UUID.test(value)) throw new TypeError('A UUID analysis id is required')
  return value
}

function meta(response) {
  return { requestId: response.headers.get('x-request-id') || undefined, retryAfterMs: retryAfter(response.headers.get('retry-after')) }
}

async function boundedResponseBytes(response, maxBytes, analysisId) {
  if (!Number.isSafeInteger(maxBytes) || maxBytes < 1) throw new TypeError('maxBytes must be a positive safe integer')
  const reader = response.body?.getReader()
  if (!reader) return new Uint8Array()
  const chunks = []
  let size = 0
  try {
    for (;;) {
      const { done, value } = await reader.read()
      if (done) break
      if (!value?.byteLength) continue
      size += value.byteLength
      if (size > maxBytes) {
        await reader.cancel('artifact_too_large').catch(() => undefined)
        throw new ForensicsApiError('artifact_too_large', { analysisId })
      }
      chunks.push(value)
    }
  } catch (error) {
    if (error instanceof ForensicsApiError) throw error
    throw new ForensicsApiError('transport_error', { analysisId })
  } finally {
    reader.releaseLock()
  }
  const bytes = new Uint8Array(size)
  let offset = 0
  for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.byteLength }
  return bytes
}

export class ForensicsClient {
  #token
  constructor({ apiKey, baseUrl = CANONICAL_BASE_URL, allowInsecureLoopback = false, fetchImpl = globalThis.fetch,
    maxRetries = 2, timeoutMs = 60_000, sleep = delay, random = Math.random } = {}) {
    if (typeof apiKey !== 'string' || !apiKey || /[\s\r\n]/.test(apiKey)) throw new TypeError('A product-scoped Ultiwrite Forensics API key is required')
    if (typeof fetchImpl !== 'function') throw new TypeError('fetchImpl is required')
    if (!Number.isInteger(maxRetries) || maxRetries < 0 || maxRetries > 5) throw new TypeError('maxRetries must be 0 through 5')
    this.#token = apiKey; this.baseUrl = validateBase(baseUrl, allowInsecureLoopback)
    Object.assign(this, { fetchImpl, maxRetries, timeoutMs, sleep, random })
  }

  url(path) {
    if (typeof path !== 'string' || !path.startsWith('/')) throw new TypeError('API path must begin with /')
    const base = new URL(`${this.baseUrl}/`)
    const relative = path.replace(/^\/api\/v1\/?/, '').replace(/^\//, '')
    const url = new URL(relative, base)
    if (url.origin !== base.origin || url.username || url.password || url.hash || !url.pathname.startsWith(base.pathname)) throw new TypeError('Refused off-origin or non-API URL')
    return url
  }

  async request(method, path, { body, headers = {}, requestKey, retryableWrite = false } = {}) {
    method = String(method).toUpperCase()
    if (!['GET', 'POST', 'DELETE'].includes(method)) throw new TypeError('Unsupported method')
    if (requestKey && !UUID.test(requestKey)) throw new TypeError('requestKey must be a UUID')
    const attempts = method === 'GET' || (method === 'POST' && requestKey && retryableWrite) ? this.maxRetries + 1 : 1
    for (let attempt = 0; attempt < attempts; attempt++) {
      let response
      try {
        response = await this.fetchImpl(this.url(path), { method, body, redirect: 'error', signal: AbortSignal.timeout(this.timeoutMs), headers: {
          authorization: `Bearer ${this.#token}`, accept: 'application/json', 'accept-encoding': 'identity', ...headers,
          ...(requestKey ? { 'idempotency-key': requestKey } : {}),
        } })
      } catch { throw new ForensicsApiError('transport_error') }
      const responseMeta = meta(response)
      if (TRANSIENT.has(response.status) && attempt + 1 < attempts) {
        await response.body?.cancel()
        await this.sleep(Math.max(responseMeta.retryAfterMs, 500 * 2 ** attempt + Math.floor(this.random() * 200)))
        continue
      }
      let value
      try { value = await response.json() } catch { value = undefined }
      if (!response.ok) {
        const candidate = typeof value?.error === 'string' ? value.error : value?.error?.code
        throw new ForensicsApiError(SAFE_CODE.test(candidate || '') ? candidate : `http_${response.status}`, { status: response.status, requestId: responseMeta.requestId, retryAfterMs: responseMeta.retryAfterMs })
      }
      if (value === undefined) throw new ForensicsApiError('invalid_json_response', { status: response.status, requestId: responseMeta.requestId })
      return { data: value, meta: responseMeta }
    }
    throw new ForensicsApiError('retry_budget_exhausted')
  }

  capabilities() { return this.request('GET', '/capabilities') }
  usage() { return this.request('GET', '/usage') }
  analyses({ limit = 50 } = {}) {
    if (!Number.isInteger(limit) || limit < 1 || limit > 100) throw new TypeError('limit must be 1 through 100')
    return this.request('GET', `/analyses?limit=${limit}`)
  }

  createAnalysis(file, { requestKey, externalChecks = false } = {}) {
    if (!file || typeof file.name !== 'string' || /[\\/\r\n\0]/.test(file.name) || !(file.bytes instanceof Uint8Array || file.bytes instanceof Blob)) throw new TypeError('file needs a plain name and Uint8Array or Blob bytes')
    const blob = file.bytes instanceof Blob ? file.bytes : new Blob([file.bytes], { type: file.type || 'application/octet-stream' })
    if (!blob.size) throw new TypeError('file must be nonempty')
    const form = new FormData(); form.set('file', blob, file.name); form.set('externalChecks', String(Boolean(externalChecks)))
    return this.request('POST', '/analyses', { body: form, requestKey, retryableWrite: true })
  }

  authorizeDirectUpload(declaration) {
    if (!UUID.test(declaration?.requestKey || '')) throw new TypeError('declaration.requestKey must be a UUID')
    return this.request('POST', '/uploads', { body: JSON.stringify(declaration), headers: { 'content-type': 'application/json' }, requestKey: declaration.requestKey, retryableWrite: true })
  }

  async transferDelegated(permission, bytes) {
    let url
    try { url = new URL(permission?.url) } catch { throw new TypeError('Invalid delegated upload permission') }
    const loopback = url.protocol === 'http:' && ['127.0.0.1', '[::1]', 'localhost'].includes(url.hostname) && this.baseUrl.startsWith('http://')
    if ((url.protocol !== 'https:' && !loopback) || url.username || url.password || url.hash || !['PUT', 'POST'].includes(permission?.method) || !permission?.headers || Array.isArray(permission.headers) || Date.parse(permission.expiresAt) <= Date.now()) throw new TypeError('Invalid delegated upload permission')
    for (const [name, value] of Object.entries(permission.headers)) if (typeof value !== 'string' || /[\r\n]/.test(name + value) || value.includes(this.#token)) throw new TypeError('Invalid delegated upload permission')
    let response
    try { response = await this.fetchImpl(url, { method: permission.method, headers: permission.headers, body: bytes, redirect: 'error', signal: AbortSignal.timeout(this.timeoutMs) }) } catch { throw new ForensicsApiError('upload_transport_error') }
    await response.body?.cancel()
    if (!response.ok) throw new ForensicsApiError('upload_failed', { status: response.status })
  }

  status(analysisId) { return this.request('GET', `/analyses/${identifier(analysisId)}`) }
  async waitForAnalysis(analysisId, { intervalMs = 5_000, timeoutMs = 15 * 60_000 } = {}) {
    const deadline = Date.now() + timeoutMs
    for (;;) {
      const current = await this.status(analysisId)
      if (current.data?.status === 'completed' && !current.data?.evidence?.locked) return current
      if (['failed', 'cancelled', 'deleting', 'deleted'].includes(current.data?.status)) return current
      if (Date.now() + intervalMs > deadline) throw new ForensicsApiError('processing_timeout', { analysisId })
      await this.sleep(intervalMs)
    }
  }

  deleteAnalysis(analysisId) { return this.request('DELETE', `/analyses/${identifier(analysisId)}`) }
  unlock(analysisId, requestKey) { return this.request('POST', `/analyses/${identifier(analysisId)}/unlock`, { requestKey, retryableWrite: true }) }

  async artifact(analysisId, artifact, { maxBytes = 128 * 1024 * 1024 } = {}) {
    if (!ARTIFACTS.includes(artifact) && artifact !== 'metadata.json') throw new TypeError('Unsupported artifact')
    if (!Number.isSafeInteger(maxBytes) || maxBytes < 1) throw new TypeError('maxBytes must be a positive safe integer')
    let response
    try { response = await this.fetchImpl(this.url(`/analyses/${identifier(analysisId)}/${artifact}`), { method: 'GET', redirect: 'error', signal: AbortSignal.timeout(this.timeoutMs), headers: { authorization: `Bearer ${this.#token}`, accept: '*/*', 'accept-encoding': 'identity' } }) } catch { throw new ForensicsApiError('transport_error', { analysisId }) }
    const responseMeta = meta(response)
    if (!response.ok) {
      let value; try { value = await response.json() } catch {}
      const candidate = typeof value?.error === 'string' ? value.error : value?.error?.code
      throw new ForensicsApiError(SAFE_CODE.test(candidate || '') ? candidate : `http_${response.status}`, { status: response.status, requestId: responseMeta.requestId, analysisId })
    }
    if ((response.headers.get('content-encoding') || 'identity').toLowerCase() !== 'identity') { await response.body?.cancel(); throw new ForensicsApiError('invalid_artifact_encoding', { analysisId }) }
    const declared = response.headers.get('content-length')
    if (declared && (!/^\d+$/.test(declared) || Number(declared) > maxBytes)) { await response.body?.cancel(); throw new ForensicsApiError('artifact_too_large', { analysisId }) }
    const bytes = await boundedResponseBytes(response, maxBytes, analysisId)
    if (!bytes.length) throw new ForensicsApiError('empty_artifact', { analysisId })
    const expected = response.headers.get('x-content-sha256')
    const sha256 = createHash('sha256').update(bytes).digest('hex')
    if (expected && (!/^[a-f0-9]{64}$/i.test(expected) || expected.toLowerCase() !== sha256)) throw new ForensicsApiError('artifact_hash_mismatch', { analysisId })
    return { data: { bytes, sha256, contentType: response.headers.get('content-type') || 'application/octet-stream' }, meta: responseMeta }
  }

  async findings(analysisId) {
    const result = await this.artifact(analysisId, 'result.json')
    let data
    try { data = JSON.parse(new TextDecoder().decode(result.data.bytes)) } catch { throw new ForensicsApiError('invalid_result_json', { analysisId }) }
    return { data, meta: result.meta }
  }
}
