import assert from 'node:assert/strict'
import test from 'node:test'
import { createServer } from 'node:http'
import { once } from 'node:events'
import { createHash } from 'node:crypto'
import { ForensicsClient } from '../index.js'

const id = '11111111-1111-4111-8111-111111111111'
async function fixture(t) {
  const calls = []
  const server = createServer(async (request, response) => {
    const chunks=[]; for await (const chunk of request) chunks.push(chunk); calls.push({method:request.method,url:request.url,headers:request.headers,body:Buffer.concat(chunks)})
    response.setHeader('x-request-id',`req_${calls.length}`)
    if (request.url === '/api/v1/usage') { response.setHeader('content-type','application/json'); response.end(JSON.stringify({available:1,reserved:0,api_execution:true,profile:'ultiwrite-forensics@1',limits:{}})) }
    else if (request.method === 'POST' && request.url === '/api/v1/analyses') { response.statusCode=202; response.setHeader('content-type','application/json'); response.end(JSON.stringify({id,status:'queued'})) }
    else if (request.url === `/api/v1/analyses/${id}/result.json`) { const body=Buffer.from(JSON.stringify({findings:[{id:'fixture'}]})); response.setHeader('content-type','application/json'); response.setHeader('x-content-sha256',createHash('sha256').update(body).digest('hex')); response.end(body) }
    else { response.statusCode=404; response.setHeader('content-type','application/json'); response.end(JSON.stringify({error:'not_found',detail:'private fixture prose'})) }
  })
  server.listen(0,'127.0.0.1'); await once(server,'listening'); t.after(()=>server.close())
  return {calls,client:new ForensicsClient({apiKey:'fixture-key',baseUrl:`http://127.0.0.1:${server.address().port}/api/v1`,allowInsecureLoopback:true})}
}

test('usage verifies the product profile selected by the key', async t => {
  const {client,calls}=await fixture(t); const usage=await client.usage()
  assert.equal(usage.data.profile,'ultiwrite-forensics@1'); assert.equal(calls[0].headers.authorization,'Bearer fixture-key'); assert.ok(!JSON.stringify(client).includes('fixture-key'))
})
test('analysis carries the UUID idempotency key and stays asynchronous', async t => {
  const {client,calls}=await fixture(t); const created=await client.createAnalysis({name:'fixture.pdf',bytes:new TextEncoder().encode('%PDF-fixture')},{requestKey:id})
  assert.equal(created.data.status,'queued'); assert.equal(calls[0].headers['idempotency-key'],id); assert.match(calls[0].headers['content-type'],/^multipart\/form-data;/)
})
test('findings use the published result artifact without starting work', async t => {
  const {client,calls}=await fixture(t); const result=await client.findings(id)
  assert.equal(result.data.findings[0].id,'fixture'); assert.deepEqual(calls.map(call=>call.method),['GET'])
})
test('safe errors expose codes without server prose', async t => {
  const {client}=await fixture(t); await assert.rejects(client.status(id),error=>error.code==='not_found'&&!error.message.includes('private fixture prose'))
})
test('artifact streaming cancels before buffering beyond the configured bound', async () => {
  let cancelled = false
  const stream = new ReadableStream({
    start(controller) {
      controller.enqueue(new Uint8Array(40))
      controller.enqueue(new Uint8Array(40))
    },
    cancel(reason) { cancelled = reason === 'artifact_too_large' },
  })
  const client = new ForensicsClient({
    apiKey: 'fixture-key',
    baseUrl: 'http://127.0.0.1:1/api/v1',
    allowInsecureLoopback: true,
    fetchImpl: async () => new Response(stream, { status: 200 }),
  })
  await assert.rejects(
    client.artifact(id, 'result.json', { maxBytes: 64 }),
    error => error.code === 'artifact_too_large',
  )
  assert.equal(cancelled, true)
})
