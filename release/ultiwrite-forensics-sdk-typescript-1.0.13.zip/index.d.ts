export const CANONICAL_BASE_URL: "https://ultiwrite.co/api/v1";
export const ARTIFACTS: readonly string[];
export interface ApiResult<T> { data: T; meta: { requestId?: string; retryAfterMs: number } }
export type JsonObject = Record<string, unknown>;
export interface UploadFile { name: string; bytes: Uint8Array | Blob; type?: string }
export interface Usage extends JsonObject { available: number; reserved: number; api_execution: boolean; profile: "ultiwrite-forensics@1"; key_scopes?: string[] }
export interface AnalysisSummary extends JsonObject { id: string; name: string; status: "queued"|"running"|"completed"|"failed"|"cancelled"|"deleting"|"deleted"; billing: "reserved"|"settled"|"released"; created_at: string }
export interface Analysis extends AnalysisSummary { report: JsonObject | null; report_expires_at?: string | null; retention_state?: string | null }
export class ForensicsApiError extends Error { code: string; status?: number; requestId?: string; retryAfterMs: number; analysisId?: string; retryable: boolean }
export function createRequestKey(): string;
export class ForensicsClient {
  constructor(options: { apiKey: string; baseUrl?: string; allowInsecureLoopback?: boolean; fetchImpl?: typeof fetch; maxRetries?: number; timeoutMs?: number; sleep?: (ms:number)=>Promise<void>; random?: ()=>number });
  capabilities(): Promise<ApiResult<JsonObject>>;
  usage(): Promise<ApiResult<Usage>>;
  analyses(options?: {limit?:number}): Promise<ApiResult<{analyses:AnalysisSummary[]}>>;
  createAnalysis(file: UploadFile, options: {requestKey:string; externalChecks?:boolean}): Promise<ApiResult<{id:string;status:string}>>;
  authorizeDirectUpload(declaration: JsonObject & {requestKey:string}): Promise<ApiResult<JsonObject>>;
  transferDelegated(permission: JsonObject, bytes: Uint8Array): Promise<void>;
  status(analysisId:string): Promise<ApiResult<Analysis>>;
  waitForAnalysis(analysisId:string, options?:{intervalMs?:number;timeoutMs?:number}): Promise<ApiResult<Analysis>>;
  deleteAnalysis(analysisId:string): Promise<ApiResult<JsonObject>>;
  unlock(analysisId:string, requestKey:string): Promise<ApiResult<JsonObject>>;
  artifact(analysisId:string, artifact:"report.pdf"|"metadata-analytics.pdf"|"result.json"|"manifest.json"|"deliverables.zip"|"metadata.json", options?:{maxBytes?:number}): Promise<ApiResult<{bytes:Uint8Array;sha256:string;contentType:string}>>;
  findings(analysisId:string): Promise<ApiResult<JsonObject>>;
}
