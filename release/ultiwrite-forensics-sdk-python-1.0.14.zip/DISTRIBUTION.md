# Prepared local Python SDK

Package version: 0.1.0. Product distribution identity: 1.0.14. Build a wheel from this reviewed directory. The package uses a local prepared name because PyPI ownership and publication are unverified. No registry publication is claimed.
