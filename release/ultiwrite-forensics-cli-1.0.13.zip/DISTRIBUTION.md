# Prepared local CLI

Package version: 0.1.0. Product distribution identity: 1.0.13. The bundled thin SDK is generated from distribution/clients/typescript/index.js. Install only from this reviewed local package; npm ownership and publication are unverified.
