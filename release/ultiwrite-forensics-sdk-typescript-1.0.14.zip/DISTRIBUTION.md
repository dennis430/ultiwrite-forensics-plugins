# Prepared local TypeScript SDK

Package version: 0.1.0. Product distribution identity: 1.0.14. Install from this reviewed directory or run npm pack --ignore-scripts. The package is private because npm ownership and publication are unverified. No registry publication or hosted acceptance is claimed.
