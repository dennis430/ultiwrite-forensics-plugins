# Ultiwrite Forensics CLI — prepared local package

This CLI is restricted to the standalone Ultiwrite Forensics API. It does not use main-platform accounts or credentials and contains no analyzer logic. Registry ownership is unverified, so the package is private and installed from a reviewed local tarball.

```bash
npm pack --ignore-scripts
npm install --global ./ultiwrite-forensics-cli-local-0.1.0.tgz
```

Create a product-scoped key at `https://ultiwrite.co/developers`, then store it without placing it in the command line:

```bash
export ULTIWRITE_FORENSICS_API_KEY='your-server-key'
ultiwrite-forensics login --profile work
unset ULTIWRITE_FORENSICS_API_KEY
ultiwrite-forensics account --profile work
```

Commands:

- `login`, `account`, `disconnect` — save/select/remove a mode-0600 local profile and verify the live product profile. The API does not return account email; the local profile label is not a server identity.
- `capabilities`, `usage`, `list [--limit 50]` — inspect current support, allowance/key budget, and recent owned analyses.
- `analyze FILE [--request-key UUID] [--no-wait]` — submit one original with a stable UUID and optionally wait for its durable state.
- `status ANALYSIS_UUID`, `findings ANALYSIS_UUID` — inspect saved state or the published structured result. A quiet check is not authenticity certification.
- `export ANALYSIS_UUID ARTIFACT --output FILE` — retrieve one of `report.pdf`, `metadata-analytics.pdf`, `result.json`, `manifest.json`, or `deliverables.zip` without another analysis.
- `delete ANALYSIS_UUID` — request the API’s cancellation/deletion lifecycle. An accepted response is not relabeled as verified cleanup.

`disconnect` removes the local copy only because the API exposes no key-revocation-by-key operation. Revoke or rotate the key at `https://ultiwrite.co/developers` when server-side invalidation is required.
