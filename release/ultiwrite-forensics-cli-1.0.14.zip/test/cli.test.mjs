import assert from 'node:assert/strict'
import test from 'node:test'
import { spawn } from 'node:child_process'
import { createServer } from 'node:http'
import { once } from 'node:events'
import { mkdtemp, readFile, rm, stat, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { createHash } from 'node:crypto'
import { ForensicsClient } from '../lib/sdk.js'

const id='11111111-1111-4111-8111-111111111111'
test('profile, analysis, findings, export and disconnect use real fixture round trips', async t => {
  const calls=[]; const pdf=Buffer.from('%PDF-safe-synthetic-fixture')
  const server=createServer(async(req,res)=>{const chunks=[];for await(const c of req)chunks.push(c);calls.push({method:req.method,url:req.url,headers:req.headers,body:Buffer.concat(chunks)});res.setHeader('x-request-id',`req_${calls.length}`)
    if(req.url==='/api/v1/usage'){res.setHeader('content-type','application/json');res.end(JSON.stringify({available:2,reserved:0,api_execution:true,profile:'ultiwrite-forensics@1',key_scopes:['forensics:read','forensics:analyze','forensics:artifacts','forensics:usage','forensics:delete'],limits:{}}))}
    else if(req.method==='POST'&&req.url==='/api/v1/analyses'){res.statusCode=202;res.setHeader('content-type','application/json');res.end(JSON.stringify({id,status:'queued'}))}
    else if(req.method==='DELETE'&&req.url===`/api/v1/analyses/${id}`){res.statusCode=202;res.setHeader('content-type','application/json');res.end(JSON.stringify({id,status:'deleting',deletionVerified:false}))}
    else if(req.url===`/api/v1/analyses/${id}`){res.setHeader('content-type','application/json');res.end(JSON.stringify({id,name:'fixture.pdf',status:'completed',billing:'settled',created_at:new Date(0).toISOString(),report:{findings:[]}}))}
    else if(req.url===`/api/v1/analyses/${id}/result.json`){const body=Buffer.from(JSON.stringify({findings:[{id:'fixture-finding'}]}));res.setHeader('content-type','application/json');res.setHeader('x-content-sha256',createHash('sha256').update(body).digest('hex'));res.end(body)}
    else if(req.url===`/api/v1/analyses/${id}/report.pdf`){res.setHeader('content-type','application/pdf');res.setHeader('x-content-sha256',createHash('sha256').update(pdf).digest('hex'));res.end(pdf)}
    else{res.statusCode=404;res.setHeader('content-type','application/json');res.end(JSON.stringify({error:'not_found'}))}})
  server.listen(0,'127.0.0.1');await once(server,'listening');t.after(()=>server.close())
  const home=await mkdtemp(join(tmpdir(),'uf-cli-'));t.after(()=>rm(home,{recursive:true,force:true}))
  const bin=fileURLToPath(new URL('../bin/ultiwrite-forensics.js',import.meta.url))
  const env={...process.env,ULTIWRITE_FORENSICS_HOME:home,ULTIWRITE_FORENSICS_BASE_URL:`http://127.0.0.1:${server.address().port}/api/v1`,ULTIWRITE_FORENSICS_TEST_MODE:'1'}
  async function run(args,extra={}){const child=spawn(process.execPath,[bin,...args],{env:{...env,...extra}});let stdout='',stderr='';child.stdout.on('data',c=>stdout+=c);child.stderr.on('data',c=>stderr+=c);const [code]=await once(child,'close');return{code,stdout,stderr}}
  let result=await run(['login','--profile','fixture'],{ULTIWRITE_FORENSICS_API_KEY:'fixture-key'});assert.equal(result.code,0,result.stderr);assert.equal(JSON.parse(result.stdout).productProfile,'ultiwrite-forensics@1')
  const credential=join(home,'credentials-fixture.json');assert.equal((await stat(credential)).mode&0o777,0o600);assert.ok((await readFile(credential,'utf8')).includes('fixture-key'))
  const input=join(home,'fixture.pdf');await writeFile(input,pdf)
  result=await run(['analyze',input,'--request-key',id,'--profile','fixture']);assert.equal(result.code,0,result.stderr);assert.equal(JSON.parse(result.stdout).analysis.status,'completed')
  result=await run(['findings',id,'--profile','fixture']);assert.equal(JSON.parse(result.stdout).findings[0].id,'fixture-finding')
  const output=join(home,'report.pdf');result=await run(['export',id,'report.pdf','--output',output,'--profile','fixture']);assert.equal(result.code,0,result.stderr);assert.deepEqual(await readFile(output),pdf)
  result=await run(['delete',id,'--profile','fixture']);assert.equal(JSON.parse(result.stdout).deletionVerified,false)
  result=await run(['disconnect','--profile','fixture']);assert.equal(result.code,0,result.stderr);await assert.rejects(readFile(credential))
  assert.ok(calls.every(call=>call.headers.authorization==='Bearer fixture-key'));assert.ok(!calls.some(call=>call.url.includes('dwsoffshorepartners.com')))
})

test('bundled CLI SDK cancels an oversized chunked artifact response', async () => {
  let cancelled=false
  const stream=new ReadableStream({
    start(controller){controller.enqueue(new Uint8Array(33));controller.enqueue(new Uint8Array(33))},
    cancel(reason){cancelled=reason==='artifact_too_large'},
  })
  const client=new ForensicsClient({apiKey:'fixture-key',baseUrl:'http://127.0.0.1:1/api/v1',allowInsecureLoopback:true,fetchImpl:async()=>new Response(stream,{status:200})})
  await assert.rejects(client.artifact(id,'report.pdf',{maxBytes:64}),error=>error.code==='artifact_too_large')
  assert.equal(cancelled,true)
})
