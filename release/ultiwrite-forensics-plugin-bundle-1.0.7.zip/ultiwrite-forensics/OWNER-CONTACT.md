# Publisher contact

DWS Offshore Fund. Owner: Dennis Liu, dennisl@ultiwrite.co. No reviewer password belongs in this archive. Reviewer credentials must be exchanged only through each portal's protected credential fields or Dennis's approved secret manager.
