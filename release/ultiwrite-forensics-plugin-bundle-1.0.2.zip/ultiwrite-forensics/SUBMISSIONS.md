# Directory and publication status

This public repository contains connector source layouts and prepared packages, version 1.0.2. Publishing files to GitHub does not publish a directory listing or prove native-host acceptance.

| Target | Public files | Remaining external step |
|---|---|---|
| ChatGPT | `chatgpt/`; release OpenAI ZIP | Organization portal, reviewer access, domain proof and review |
| Claude / Claude Code | Root marketplace and `claude/` | Repository installation available; connector-directory review is separate |
| Cursor | Root plugin and `cursor/` | Repository/deeplink installation available; marketplace review is separate |
| Codex | Root plugin, `.mcp.json`, config example and `codex/` | OAuth installation; no hosted listing implied |
| Gemini CLI | Root extension and `gemini-cli/` | Repository installation; gallery discovery/acceptance is separate |
| Google Antigravity | `antigravity/` | Partner intake and native validation |
| Microsoft 365 Copilot | `microsoft-365/` | **Blocked for submission** until the Developer Portal issues the DCR reference |
| Official MCP Registry | Root `server.json` and `mcp-registry/` | Prove ownership of ultiwrite.co, validate with mcp-publisher, and explicitly authorize publication |
| VS Code / GitHub Copilot, Grok, Mistral | `guides/` | Manual connection; directory availability depends on the host |
| ReadMe / Mintlify | `guides/readme.md`, `guides/mintlify.md` | Separate documentation-project access; no invented plugin upload format |
| Other partner channels | See live setup guide and host documentation | Enrollment and actual requirements must be verified |

The preferred npm identifier `@ultiwrite/forensics-mcp` remains ownership-unverified. The current remote HTTP connector requires no npm package. Never repurpose the flagship npm name, OAuth client, marketplace entry or commercial grants.

The Microsoft reference is maintained once in private canonical identity at `packages.microsoftDcrReferenceId`; regenerate all packages after the portal issues it. Do not hand-edit generated identities. No permanent document retention: Source files are deleted after processing, at the latest one hour after upload. Reports stay available for download for up to 24 hours, then they are deleted.

For current setup and policies: https://ultiwrite.co/docs/mcp · https://ultiwrite.co/privacy · https://ultiwrite.co/data-retention.
